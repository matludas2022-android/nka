# Home's Music (v2.0)
### Audiophile Android Music Player with Media3, 20-Band Dynamics, Dolby Atmos & DJ Gapless Crossfade

Home's Music v2.0 integrates high-performance modern Android architecture with:
0. **Branding:** Rebranded to **Home's Music**.
1. **Dual-Stage Bass Tuning:** Separate **Sub-Bass (20-60Hz rumble)** and **Punchy Bass (70-160Hz kick)** for crystal clarity and deep chest vibration.
2. **Zero-Distortion DynamicsProcessing Limiter & AGC:**
   - True Brickwall Peak Limiter (-0.2 dBFS ceiling) and Multi-Band Compressor AGC.
   - Guaranteed **0% distortion** even when the bass is turned up to 100% full maximum!
3. **Dolby Surround / Spatial Audio & 3D Virtualizer Knob:**
   - On/Off Switch with 3D Virtualizer Knob (0 - 1000).
   - Android `Spatializer` API & `AudioEffect.EFFECT_TYPE_VIRTUALIZER`.
   - Triggers device inbuilt Dolby Atmos session broadcast (`AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION`).
4. **Unlimited Custom Presets (Save & Rename):**
   - Save unlimited custom EQ presets with persistent SharedPreferences storage.
   - Full support to Rename (रीनेम) and Delete any preset anytime.
5. **UI Visualizer Effect (10 Floating Beat Bubbles):**
   - 10 physics-based audio-reactive glowing bubbles that bounce dynamically to kick drums and bass frequencies on the "Now Playing" screen.
6. **Multi-Folder Batch Queue ("Play Next" & "Add to Queue"):**
   - Multi-folder SAF selection with instant popup: "Play Next", "Add to Current Playing Queue", or "Play Now".
7. **Premium Media3 Lock Screen & Notification Controls:**
   - Android 13/14/15 native interactive Seek Bar (Scrubber) directly on Lock Screen.
   - Dynamic high-resolution album artwork generation and metadata display.

---

## Building in Android Studio
1. Open this directory in **Android Studio Ladybug / Meerkat (2024.2+)**.
2. Make sure JDK 17 is configured under `Settings -> Build, Execution, Deployment -> Build Tools -> Gradle -> Gradle JDK`.
3. Sync Gradle (`File -> Sync Project with Gradle Files`).
4. Click **Build -> Build APK(s)** or click the green **Run** button to install on your Android device (e.g. Dolby).
