package com.homesmusic.app.ui.theme

import androidx.compose.ui.graphics.Color

val AmoledBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF0C0C0E)
val DarkSurfaceElevated = Color(0xFF141418)
val DarkBorder = Color(0xFF222228)

val AudiophileCyan = Color(0xFF06B6D4)
val AudiophileBlue = Color(0xFF3B82F6)
val AudiophileEmerald = Color(0xFF10B981)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF94A3B8)
val TextSubtle = Color(0xFF64748B)

val SliderTrackDark = Color(0xFF1E1E24)
