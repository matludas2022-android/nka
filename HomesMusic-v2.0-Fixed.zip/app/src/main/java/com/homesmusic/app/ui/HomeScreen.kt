package com.homesmusic.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.homesmusic.app.model.AudioTrack
import com.homesmusic.app.ui.theme.AmoledBlack
import com.homesmusic.app.ui.theme.AudiophileCyan
import com.homesmusic.app.ui.theme.DarkBorder
import com.homesmusic.app.ui.theme.DarkSurface
import com.homesmusic.app.ui.theme.DarkSurfaceElevated
import com.homesmusic.app.ui.theme.SliderTrackDark
import com.homesmusic.app.ui.theme.TextMuted
import com.homesmusic.app.ui.theme.TextSubtle
import com.homesmusic.app.ui.theme.TextWhite
import com.homesmusic.app.viewmodel.MusicPlayerViewModel

/**
 * Home's Music Main Screen:
 * 1. Multi-Folder selection with Instant Queue popup.
 * 2. 10 Beat-dancing Bubbles reactive visualizer.
 * 3. Smart DJ Gapless Crossfade status badge.
 * 4. High-contrast playback controls & lockscreen-matched layout.
 */
@Composable
fun HomeScreen(
    viewModel: MusicPlayerViewModel,
    onNavigateToEqualizer: () -> Unit
) {
    val selectedFolders by viewModel.selectedFolders.collectAsState()
    val pendingTracks by viewModel.pendingTracks.collectAsState()
    val showQueueActionPopup by viewModel.showQueueActionPopup.collectAsState()
    val tracks by viewModel.tracks.collectAsState()
    val currentTrack by viewModel.currentTrack.collectAsState()
    val currentTrackIndex by viewModel.currentTrackIndex.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentPos by viewModel.currentPosition.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val bubbleAmps by viewModel.bubbleAmplitudes.collectAsState()
    val isCrossfadeEnabled by viewModel.isCrossfadeEnabled.collectAsState()
    val crossfadeDurationMs by viewModel.crossfadeDurationMs.collectAsState()
    val crossfadeStatus by viewModel.crossfadeStatus.collectAsState()
    val isDolbyActive by viewModel.isDolbyAtmosActive.collectAsState()

    var showQueueDrawer by remember { mutableStateOf(false) }

    // SAF Folder Picker launcher
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onSingleFolderSelected(uri)
        }
    }

    val progress = if (duration > 0) (currentPos.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f

    // 10 Bubble Neon Color Palette
    val bubbleColors = listOf(
        Color(0xFF06B6D4), // Cyan
        Color(0xFF3B82F6), // Blue
        Color(0xFF6366F1), // Indigo
        Color(0xFF8B5CF6), // Purple
        Color(0xFFA855F7), // Magenta
        Color(0xFFD946EF), // Pink
        Color(0xFFEC4899), // Rose
        Color(0xFFF43F5E), // Coral
        Color(0xFFF59E0B), // Amber
        Color(0xFF10B981)  // Emerald
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = AmoledBlack
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Top Bar: Branding, EQ & Dolby Quick Indicator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Home's Music",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = TextWhite,
                            letterSpacing = (-0.5).sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(AudiophileCyan.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "HOME'S MUSIC",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = AudiophileCyan
                            )
                        }
                    }
                    Text(
                        text = if (isDolbyActive) "Dolby Atmos & 3D Spatial Audio • 20-Band Dynamics" else "Hi-Res Audio Engine • 24-bit/96kHz",
                        fontSize = 11.sp,
                        color = TextSubtle
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Queue Button with badge
                    IconButton(
                        onClick = { showQueueDrawer = !showQueueDrawer },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            Icon(
                                imageVector = Icons.Default.QueueMusic,
                                contentDescription = "Queue",
                                tint = if (showQueueDrawer) AudiophileCyan else TextWhite,
                                modifier = Modifier.size(24.dp)
                            )
                            if (tracks.isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .background(AudiophileCyan, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${tracks.size.coerceAtMost(99)}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AmoledBlack
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Equalizer & Dolby Navigation Button
                    IconButton(
                        onClick = onNavigateToEqualizer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Equalizer,
                            contentDescription = "20-Band EQ & Dolby",
                            tint = AudiophileCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Multi-Folder Selection Bar
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(width = 1.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                tint = AudiophileCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Selected Folders (${selectedFolders.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextWhite
                            )
                        }

                        // Add Folder Button (Multi-folder workflow)
                        Button(
                            onClick = { folderPickerLauncher.launch(null) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AudiophileCyan,
                                contentColor = AmoledBlack
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                horizontal = 10.dp,
                                vertical = 4.dp
                            ),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Select Folder", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (selectedFolders.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(selectedFolders) { folder ->
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(DarkSurfaceElevated)
                                        .border(1.dp, DarkBorder, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Folder,
                                        contentDescription = null,
                                        tint = AudiophileCyan,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = folder.name,
                                        fontSize = 11.sp,
                                        color = TextWhite,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove",
                                        tint = TextMuted,
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clickable { viewModel.removeFolder(folder) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Smart DJ Gapless Crossfade Status Pill
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurface)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                if (isCrossfadeEnabled) AudiophileCyan else TextMuted,
                                CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isCrossfadeEnabled) "DJ Gapless Crossfade (${crossfadeDurationMs / 1000}s)" else "Gapless Playback (0s silence)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isCrossfadeEnabled) TextWhite else TextMuted
                    )
                }
                if (crossfadeStatus != null) {
                    Text(
                        text = crossfadeStatus ?: "",
                        fontSize = 10.sp,
                        color = AudiophileCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Content: Track List or Queue View
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (isScanning) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = AudiophileCyan)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "Scanning audio files instantly...",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else if (tracks.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                "No Audio Folders Selected",
                                color = TextWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Tap 'Select Folder' to choose 4-5 music directories. You will be prompted with Multi-Folder queue options instantly.",
                                color = TextMuted,
                                fontSize = 12.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { folderPickerLauncher.launch(null) },
                                colors = ButtonDefaults.buttonColors(containerColor = AudiophileCyan, contentColor = AmoledBlack)
                            ) {
                                Text("Choose Music Folders", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        itemsIndexed(tracks) { index, track ->
                            val isSelected = (currentTrack?.id == track.id)
                            TrackRow(
                                track = track,
                                queuePosition = index + 1,
                                isSelected = isSelected,
                                isPlaying = isPlaying && isSelected,
                                onClick = { viewModel.playTrackAtIndex(index) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bottom Player Section with 10 Dancing Beat Bubbles & Media3 Scrubber
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(18.dp),
                border = CardDefaults.outlinedCardBorder().copy(width = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    // Track Title & Artist
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentTrack?.title ?: "Select a song to play",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${currentTrack?.artist ?: "Home's Music"} • ${currentTrack?.folderName ?: "Playing Queue"}",
                                fontSize = 12.sp,
                                color = TextSubtle,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Dolby / Spatial pill
                        if (isDolbyActive) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF38BDF8).copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "DOLBY ATMOS",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF38BDF8)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 10 DANCING BUBBLES ON BEATS (Dynamic reactive physics)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(AmoledBlack.copy(alpha = 0.6f))
                            .padding(horizontal = 14.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        bubbleColors.forEachIndexed { i, color ->
                            val amp = bubbleAmps.getOrElse(i) { 0.2f }
                            val targetOffset = if (isPlaying) -((amp * 20f) + (i % 3) * 2f) else -2f
                            val animOffset by animateFloatAsState(
                                targetValue = targetOffset,
                                animationSpec = tween(durationMillis = 80, easing = FastOutSlowInEasing),
                                label = "bubble_bounce_$i"
                            )
                            val animScale by animateFloatAsState(
                                targetValue = if (isPlaying) 0.85f + (amp * 0.55f) else 0.85f,
                                animationSpec = tween(durationMillis = 80),
                                label = "bubble_scale_$i"
                            )

                            Box(
                                modifier = Modifier
                                    .size((9 * animScale).dp)
                                    .offset(y = animOffset.dp)
                                    .clip(CircleShape)
                                    .background(color)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Progress / Seek Bar (Lock Screen matched scrubber)
                    Slider(
                        value = progress,
                        onValueChange = { newProgress ->
                            val seekTarget = (newProgress * duration).toLong()
                            viewModel.seekTo(seekTarget)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = AudiophileCyan,
                            activeTrackColor = AudiophileCyan,
                            inactiveTrackColor = SliderTrackDark
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatTime(currentPos),
                            fontSize = 11.sp,
                            color = TextSubtle
                        )
                        Text(
                            text = formatTime(duration),
                            fontSize = 11.sp,
                            color = TextSubtle
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Large, Crystal-Clear Playback Buttons (Previous, Play/Pause, Next)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Previous
                        IconButton(
                            onClick = { viewModel.skipToPrevious() },
                            modifier = Modifier.size(54.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipPrevious,
                                contentDescription = "Previous Track",
                                tint = TextWhite,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(22.dp))

                        // Large Play/Pause Primary Action Button (68dp)
                        IconButton(
                            onClick = { viewModel.togglePlayPause() },
                            modifier = Modifier
                                .size(68.dp)
                                .shadow(8.dp, CircleShape)
                                .background(AudiophileCyan, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = AmoledBlack,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(22.dp))

                        // Next
                        IconButton(
                            onClick = { viewModel.skipToNext() },
                            modifier = Modifier.size(54.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = "Next Track",
                                tint = TextWhite,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // --- Multi-Folder Instant Queue Selection Pop-Up Dialog ---
    if (showQueueActionPopup) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissQueueActionPopup() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PlaylistAdd,
                        contentDescription = null,
                        tint = AudiophileCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Multi-Folder Queue Options",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = "Found ${pendingTracks.size} audio tracks in selected folder(s).",
                        fontSize = 14.sp,
                        color = TextWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Choose how you would like to queue these songs:",
                        fontSize = 12.sp,
                        color = TextSubtle
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Option 1: Play Next (Next in queue)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playPendingNext() },
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = null,
                                tint = AudiophileCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Play Next (अगला गाना यह बजाएं)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = "Inserts right after current playing song",
                                    fontSize = 10.sp,
                                    color = TextSubtle
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Option 2: Add to Current Playing Queue (Append to queue)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.addPendingToQueue() },
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.QueueMusic,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Add to Current Playing Queue",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = "Appends all tracks to the end of queue without interrupting",
                                    fontSize = 10.sp,
                                    color = TextSubtle
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Option 3: Play Now (Replace queue)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playPendingNow() },
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Play Now (तुरंत चलाएं)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = "Start playing track 1 immediately",
                                    fontSize = 10.sp,
                                    color = TextSubtle
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.dismissQueueActionPopup() },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel", color = TextWhite)
                }
            },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun TrackRow(
    track: AudioTrack,
    queuePosition: Int,
    isSelected: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) DarkSurfaceElevated else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(
                    if (isSelected) AudiophileCyan.copy(alpha = 0.2f) else DarkSurface,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isPlaying) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = AudiophileCyan,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Text(
                    text = "$queuePosition",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) AudiophileCyan else TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isSelected) AudiophileCyan else TextWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${track.artist} • ${track.folderName}",
                fontSize = 11.sp,
                color = TextSubtle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Text(
            text = track.formattedDuration,
            fontSize = 12.sp,
            color = if (isSelected) AudiophileCyan else TextSubtle
        )
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
