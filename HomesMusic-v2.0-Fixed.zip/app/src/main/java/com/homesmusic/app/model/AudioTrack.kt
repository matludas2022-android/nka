package com.homesmusic.app.model

import android.net.Uri

/**
 * Represents an audio track scanned from the user's chosen folder via Storage Access Framework.
 */
data class AudioTrack(
    val id: String,
    val title: String,
    val artist: String = "Unknown Artist",
    val album: String = "Unknown Album",
    val durationMs: Long = 0L,
    val uri: Uri,
    val fileName: String,
    val mimeType: String = "audio/mpeg",
    val sizeBytes: Long = 0L,
    val folderName: String = "Internal Audio",
    val folderUri: String = "",
    val artworkUri: Uri? = null
) {
    val formattedDuration: String
        get() {
            if (durationMs <= 0) return "--:--"
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return "%d:%02d".format(minutes, seconds)
        }
}
