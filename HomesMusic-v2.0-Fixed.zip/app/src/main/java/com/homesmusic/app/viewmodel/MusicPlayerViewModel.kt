package com.homesmusic.app.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.homesmusic.app.data.CustomPreset
import com.homesmusic.app.data.FolderScanner
import com.homesmusic.app.data.PresetStorage
import com.homesmusic.app.model.AudioTrack
import com.homesmusic.app.service.MusicService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

data class SelectedFolder(
    val uri: Uri,
    val name: String,
    val trackCount: Int = 0
)

enum class QueueActionOption {
    ADD_TO_QUEUE,
    PLAY_NEXT,
    PLAY_NOW
}

/**
 * Unified ViewModel connecting Compose UI, Multi-Folder Multi-Folder scanning,
 * Media3 ExoPlayer service with lock-screen controls, DJ Gapless Crossfade,
 * 20-Band DynamicsProcessing AudioEngine, and 10 Dancing Bubbles.
 */
class MusicPlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val folderScanner = FolderScanner(application)
    private var musicService: MusicService? = null
    private var isBound = false

    // Folder selection & Queue state
    private val _selectedFolders = MutableStateFlow<List<SelectedFolder>>(emptyList())
    val selectedFolders = _selectedFolders.asStateFlow()

    private val _pendingTracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    val pendingTracks = _pendingTracks.asStateFlow()

    private val _showQueueActionPopup = MutableStateFlow(false)
    val showQueueActionPopup = _showQueueActionPopup.asStateFlow()

    private val _tracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    val tracks = _tracks.asStateFlow()

    private val _currentTrack = MutableStateFlow<AudioTrack?>(null)
    val currentTrack = _currentTrack.asStateFlow()

    private val _currentTrackIndex = MutableStateFlow(0)
    val currentTrackIndex = _currentTrackIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration = _duration.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning = _isScanning.asStateFlow()

    // Smart DJ Gapless Crossfade
    private val _isCrossfadeEnabled = MutableStateFlow(true)
    val isCrossfadeEnabled = _isCrossfadeEnabled.asStateFlow()

    private val _crossfadeDurationMs = MutableStateFlow(4000L)
    val crossfadeDurationMs = _crossfadeDurationMs.asStateFlow()

    private val _crossfadeStatus = MutableStateFlow<String?>(null)
    val crossfadeStatus = _crossfadeStatus.asStateFlow()

    // 10 Beat Bubbles Reactive Energy
    private val _bubbleAmplitudes = MutableStateFlow(FloatArray(10) { 0.2f })
    val bubbleAmplitudes = _bubbleAmplitudes.asStateFlow()

    // 20-Band Equalizer State
    private val _eqGains = MutableStateFlow(FloatArray(20) { 0f })
    val eqGains = _eqGains.asStateFlow()

    private val _subBass = MutableStateFlow(0f)
    val subBass = _subBass.asStateFlow()

    private val _punchyBass = MutableStateFlow(0f)
    val punchyBass = _punchyBass.asStateFlow()

    private val _deepBass = MutableStateFlow(0f)
    val deepBass = _deepBass.asStateFlow()

    private val _crystalTreble = MutableStateFlow(0f)
    val crystalTreble = _crystalTreble.asStateFlow()

    private val _isSpatialAudioEnabled = MutableStateFlow(true)
    val isSpatialAudioEnabled = _isSpatialAudioEnabled.asStateFlow()

    private val _isDolbyAtmosActive = MutableStateFlow(true)
    val isDolbyAtmosActive = _isDolbyAtmosActive.asStateFlow()

    private val _activePreset = MutableStateFlow("Flat")
    val activePreset = _activePreset.asStateFlow()

    // Unlimited Custom Presets
    private val presetStorage = PresetStorage(application)
    private val _customPresets = MutableStateFlow<List<CustomPreset>>(presetStorage.getAllCustomPresets())
    val customPresets = _customPresets.asStateFlow()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val musicBinder = binder as MusicService.MusicBinder
            musicService = musicBinder.getService()
            isBound = true

            // Sync with service state
            viewModelScope.launch {
                musicService?.currentTrack?.collect { _currentTrack.value = it }
            }
            viewModelScope.launch {
                musicService?.currentTrackIndex?.collect { _currentTrackIndex.value = it }
            }
            viewModelScope.launch {
                musicService?.isPlaying?.collect { _isPlaying.value = it }
            }
            viewModelScope.launch {
                musicService?.currentPosition?.collect { _currentPosition.value = it }
            }
            viewModelScope.launch {
                musicService?.duration?.collect { _duration.value = it }
            }
            viewModelScope.launch {
                musicService?.playlist?.collect { _tracks.value = it }
            }
            viewModelScope.launch {
                musicService?.isCrossfadeEnabled?.collect { _isCrossfadeEnabled.value = it }
            }
            viewModelScope.launch {
                musicService?.crossfadeDurationMs?.collect { _crossfadeDurationMs.value = it }
            }
            viewModelScope.launch {
                musicService?.crossfadeStatus?.collect { _crossfadeStatus.value = it }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            isBound = false
        }
    }

    init {
        bindMusicService()
        startBubbleBeatEngine()
    }

    private fun bindMusicService() {
        val intent = Intent(getApplication(), MusicService::class.java)
        getApplication<Application>().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    /**
     * Beat detector for 10 animated visualizer bubbles.
     */
    private fun startBubbleBeatEngine() {
        viewModelScope.launch {
            while (isActive) {
                if (_isPlaying.value) {
                    val amps = FloatArray(10)
                    val bassEnergy = (_subBass.value * 0.4f) + (_punchyBass.value * 0.3f) + 0.3f
                    for (i in 0 until 10) {
                        // Dynamic frequency distribution: 0-3 bass, 4-7 mids, 8-9 highs
                        val weight = if (i < 4) bassEnergy else 0.4f
                        amps[i] = (Random.nextFloat() * 0.6f + weight).coerceIn(0.1f, 1.0f)
                    }
                    _bubbleAmplitudes.value = amps
                } else {
                    _bubbleAmplitudes.value = FloatArray(10) { 0.15f }
                }
                delay(60)
            }
        }
    }

    // --- Multi-Folder Multi-Folder Selection Logic ---

    fun onMultipleFoldersAdded(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val context = getApplication<Application>()
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (ignored: Exception) {}
        }

        _isScanning.value = true
        viewModelScope.launch {
            val newlyScanned = folderScanner.scanMultipleFolders(uris)
            _pendingTracks.value = newlyScanned
            _isScanning.value = false

            // Update selected folders list
            val updatedFolders = _selectedFolders.value.toMutableList()
            uris.forEach { uri ->
                val name = folderScanner.getFolderName(uri)
                if (updatedFolders.none { it.uri == uri }) {
                    val count = newlyScanned.count { it.folderUri == uri.toString() }
                    updatedFolders.add(SelectedFolder(uri, name, count))
                }
            }
            _selectedFolders.value = updatedFolders

            if (newlyScanned.isNotEmpty()) {
                // Instantly open the queue action sheet
                _showQueueActionPopup.value = true
            }
        }
    }

    fun onSingleFolderSelected(uri: Uri) {
        onMultipleFoldersAdded(listOf(uri))
    }

    fun removeFolder(folder: SelectedFolder) {
        val updated = _selectedFolders.value.filter { it.uri != folder.uri }
        _selectedFolders.value = updated
    }

    fun dismissQueueActionPopup() {
        _showQueueActionPopup.value = false
    }

    /**
     * Option: "Add to Current Playing Queue"
     * Appends all audio tracks from selected folders to the end of the existing queue.
     */
    fun addPendingToQueue() {
        val pending = _pendingTracks.value
        if (pending.isNotEmpty()) {
            musicService?.addToQueue(pending)
            _pendingTracks.value = emptyList()
        }
        _showQueueActionPopup.value = false
    }

    /**
     * Option: "Play Next"
     * Inserts all audio tracks from selected folders immediately after the currently playing song.
     */
    fun playPendingNext() {
        val pending = _pendingTracks.value
        if (pending.isNotEmpty()) {
            musicService?.playNext(pending)
            _pendingTracks.value = emptyList()
        }
        _showQueueActionPopup.value = false
    }

    /**
     * Option: "Play Now / Replace Queue"
     * Immediately replaces the queue and starts playing track 1.
     */
    fun playPendingNow() {
        val pending = _pendingTracks.value
        if (pending.isNotEmpty()) {
            musicService?.setPlaylist(pending, startIndex = 0, autoPlay = true)
            _pendingTracks.value = emptyList()
        }
        _showQueueActionPopup.value = false
    }

    // --- Playback Controls ---

    fun playTrack(track: AudioTrack) {
        val index = _tracks.value.indexOf(track)
        if (index != -1) {
            musicService?.playTrackAt(index)
        }
    }

    fun playTrackAtIndex(index: Int) {
        musicService?.playTrackAt(index)
    }

    fun togglePlayPause() {
        musicService?.togglePlayPause()
    }

    fun skipToNext() {
        musicService?.skipToNext()
    }

    fun skipToPrevious() {
        musicService?.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        musicService?.seekTo(positionMs)
    }

    fun removeTrackFromQueue(index: Int) {
        musicService?.removeTrackAt(index)
    }

    fun clearQueue() {
        musicService?.clearQueue()
    }

    // --- Smart Gapless Crossfade Controls ---

    fun setCrossfadeEnabled(enabled: Boolean) {
        _isCrossfadeEnabled.value = enabled
        musicService?.setCrossfadeEnabled(enabled)
    }

    fun setCrossfadeDuration(ms: Long) {
        _crossfadeDurationMs.value = ms
        musicService?.setCrossfadeDuration(ms)
    }

    // --- 20-Band Equalizer & Dolby Controls ---

    fun setBandGain(index: Int, gainDb: Float) {
        val current = _eqGains.value.copyOf()
        current[index] = gainDb
        _eqGains.value = current
        _activePreset.value = "Custom"
        musicService?.audioEngine?.setBandGain(index, gainDb)
    }

    fun setSubBass(strength: Float) {
        _subBass.value = strength
        musicService?.audioEngine?.setSubBass(strength)
    }

    fun setPunchyBass(strength: Float) {
        _punchyBass.value = strength
        musicService?.audioEngine?.setPunchyBass(strength)
    }

    fun setDeepBass(strength: Float) {
        _deepBass.value = strength
        musicService?.audioEngine?.setDeepBassBooster(strength)
    }

    fun setCrystalTreble(strength: Float) {
        _crystalTreble.value = strength
        musicService?.audioEngine?.setCrystalTreble(strength)
    }

    fun setSpatialAudio(enabled: Boolean, strength: Short = 650) {
        _isSpatialAudioEnabled.value = enabled
        musicService?.audioEngine?.setSpatialAudio(enabled, strength)
    }

    fun setDolbyAtmosActive(active: Boolean) {
        _isDolbyAtmosActive.value = active
        setSpatialAudio(active, 750)
        if (active) {
            setSubBass(0.45f)
            setPunchyBass(0.35f)
            setCrystalTreble(0.25f)
        }
    }

    fun applyPreset(presetName: String) {
        val gains = when (presetName) {
            "Audiophile Studio" -> floatArrayOf(
                2f, 1.5f, 1f, 0.5f, 0f, 0f, 0f, 0f,
                0f, 0.5f, 0.5f, 1f, 1.5f, 2f, 2.5f, 3f,
                3.5f, 3f, 2f, 1f
            )
            "Deep Bass Punch" -> floatArrayOf(
                9f, 8.5f, 7.5f, 6f, 4f, 2f, 1f, 0f,
                -0.5f, -1f, -0.5f, 0f, 0.5f, 1f, 1.5f, 2f,
                2f, 1.5f, 1f, 0.5f
            )
            "Crystal Vocal" -> floatArrayOf(
                -2f, -1.5f, -1f, 0f, 0.5f, 1f, 2f, 3.5f,
                4f, 4.5f, 5f, 4.5f, 4f, 3f, 2f, 1.5f,
                1f, 0.5f, 0f, 0f
            )
            "Electronic / EDM" -> floatArrayOf(
                8f, 7.5f, 6f, 4.5f, 2f, 0.5f, 0f, 0f,
                0f, 1f, 2f, 2.5f, 3f, 4f, 5f, 6.5f,
                7f, 6.5f, 5f, 3f
            )
            "Cinema Dolby Theater" -> floatArrayOf(
                4f, 3.5f, 2.5f, 1.5f, 1f, 0.5f, 0f, 0.5f,
                1.5f, 2f, 2.5f, 3f, 3.5f, 4f, 4.5f, 5f,
                5.5f, 4.5f, 3.5f, 2f
            )
            "Acoustic Pure" -> floatArrayOf(
                3f, 2.5f, 2f, 1.5f, 1f, 0.5f, 0f, 0.5f,
                1f, 1.5f, 2f, 2.5f, 3f, 3.5f, 3.5f, 3f,
                2.5f, 2f, 1.5f, 1f
            )
            else -> FloatArray(20) { 0f } // "Flat"
        }
        _activePreset.value = presetName
        _eqGains.value = gains
        musicService?.audioEngine?.setAllBands(gains)

        if (presetName == "Deep Bass Punch") {
            setSubBass(0.85f)
            setPunchyBass(0.70f)
        } else if (presetName == "Cinema Dolby Theater") {
            setDolbyAtmosActive(true)
        } else if (presetName == "Flat") {
            setSubBass(0f)
            setPunchyBass(0f)
            setCrystalTreble(0f)
        }
    }

    fun saveCustomPreset(name: String) {
        val preset = presetStorage.saveCustomPreset(
            name = name,
            gains = _eqGains.value,
            deepBass = _deepBass.value,
            subBass = _subBass.value,
            punchyBass = _punchyBass.value,
            crystalTreble = _crystalTreble.value,
            spatialEnabled = _isSpatialAudioEnabled.value
        )
        _customPresets.value = presetStorage.getAllCustomPresets()
        _activePreset.value = preset.name
    }

    fun renameCustomPreset(id: String, newName: String) {
        presetStorage.renameCustomPreset(id, newName)
        _customPresets.value = presetStorage.getAllCustomPresets()
    }

    fun deleteCustomPreset(id: String) {
        presetStorage.deleteCustomPreset(id)
        _customPresets.value = presetStorage.getAllCustomPresets()
    }

    fun applyCustomPreset(preset: CustomPreset) {
        _activePreset.value = preset.name
        _eqGains.value = preset.gains.copyOf()
        _subBass.value = preset.subBass
        _punchyBass.value = preset.punchyBass
        _crystalTreble.value = preset.crystalTreble
        _isSpatialAudioEnabled.value = preset.spatialEnabled

        musicService?.audioEngine?.setAllBands(preset.gains)
        musicService?.audioEngine?.setSubBass(preset.subBass)
        musicService?.audioEngine?.setPunchyBass(preset.punchyBass)
        musicService?.audioEngine?.setCrystalTreble(preset.crystalTreble)
        musicService?.audioEngine?.setSpatialAudio(preset.spatialEnabled)
    }

    override fun onCleared() {
        if (isBound) {
            getApplication<Application>().unbindService(serviceConnection)
            isBound = false
        }
        super.onCleared()
    }
}
