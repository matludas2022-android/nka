package com.homesmusic.app.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.homesmusic.app.model.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Scans audio files strictly from user-selected folders via Android Storage Access Framework (SAF).
 * Supports multi-folder batch scanning.
 */
class FolderScanner(private val context: Context) {

    private val supportedExtensions = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg")
    private val supportedMimeTypes = setOf(
        "audio/mpeg", "audio/x-wav", "audio/wav", "audio/flac", "audio/x-flac",
        "audio/mp4", "audio/aac", "audio/ogg", "audio/x-m4a"
    )

    /**
     * Scans a single folder URI and returns all audio tracks found.
     */
    suspend fun scanFolder(treeUri: Uri): List<AudioTrack> = withContext(Dispatchers.IO) {
        val folderName = getFolderName(treeUri)
        val tracks = mutableListOf<AudioTrack>()
        val rootDoc = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        if (!rootDoc.isDirectory) return@withContext emptyList()

        val children = rootDoc.listFiles()
        for (file in children) {
            if (file.isFile && isAudioFile(file)) {
                val track = parseAudioTrack(file, folderName, treeUri.toString())
                if (track != null) {
                    tracks.add(track)
                }
            }
        }
        tracks.sortedBy { it.title.lowercase() }
    }

    /**
     * Multi-Folder Multi-Folder Scanner:
     * Scans multiple selected folders in parallel/concurrently and returns a unified list.
     */
    suspend fun scanMultipleFolders(treeUris: List<Uri>): List<AudioTrack> = withContext(Dispatchers.IO) {
        val allTracks = mutableListOf<AudioTrack>()
        for (uri in treeUris) {
            try {
                val tracks = scanFolder(uri)
                allTracks.addAll(tracks)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // Deduplicate by URI while maintaining discovery order
        allTracks.distinctBy { it.uri.toString() }
    }

    private fun isAudioFile(file: DocumentFile): Boolean {
        val name = file.name?.lowercase() ?: return false
        val extension = name.substringAfterLast('.', "")
        if (supportedExtensions.contains(extension)) {
            return true
        }
        val mime = file.type?.lowercase() ?: ""
        return supportedMimeTypes.contains(mime) || mime.startsWith("audio/")
    }

    private fun parseAudioTrack(file: DocumentFile, folderName: String, folderUri: String): AudioTrack? {
        val uri = file.uri
        val fileName = file.name ?: "Unknown Track"
        val retriever = MediaMetadataRetriever()
        var title = fileName.substringBeforeLast('.')
        var artist = "Unknown Artist"
        var album = "Unknown Album"
        var durationMs = 0L

        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                retriever.setDataSource(pfd.fileDescriptor)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.let {
                    if (it.isNotBlank()) title = it
                }
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.let {
                    if (it.isNotBlank()) artist = it
                }
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.let {
                    if (it.isNotBlank()) album = it
                }
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.let {
                    durationMs = it.toLongOrNull() ?: 0L
                }
            }
        } catch (e: Exception) {
            // Fallback to filename
        } finally {
            try {
                retriever.release()
            } catch (ignored: Exception) {}
        }

        return AudioTrack(
            id = UUID.randomUUID().toString(),
            title = title,
            artist = artist,
            album = album,
            durationMs = durationMs,
            uri = uri,
            fileName = fileName,
            mimeType = file.type ?: "audio/mpeg",
            sizeBytes = file.length(),
            folderName = folderName,
            folderUri = folderUri
        )
    }

    /**
     * Resolves human-readable folder name from SAF tree URI.
     */
    fun getFolderName(treeUri: Uri): String {
        return try {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val parts = docId.split(":")
            if (parts.size > 1) {
                val subPath = parts[1]
                subPath.substringAfterLast('/')
            } else {
                docId.substringAfterLast('/')
            }
        } catch (e: Exception) {
            "Audio Folder"
        }
    }
}
