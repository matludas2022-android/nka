package com.homesmusic.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = AudiophileCyan,
    onPrimary = AmoledBlack,
    secondary = AudiophileBlue,
    background = AmoledBlack,
    surface = DarkSurface,
    onBackground = TextWhite,
    onSurface = TextWhite,
    surfaceVariant = DarkSurfaceElevated,
    outline = DarkBorder
)

@Composable
fun HomesMusicTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = AmoledBlack.toArgb()
            window.navigationBarColor = AmoledBlack.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}

@Composable
fun HomesMusicTheme(content: @Composable () -> Unit) {
    HomesMusicTheme(content)
}
