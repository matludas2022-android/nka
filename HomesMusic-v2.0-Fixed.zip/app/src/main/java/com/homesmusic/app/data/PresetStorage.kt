package com.homesmusic.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Data model for custom user-created equalizer presets.
 */
data class CustomPreset(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val gains: FloatArray,
    val deepBass: Float = 0f,
    val subBass: Float = 0f,
    val punchyBass: Float = 0f,
    val crystalTreble: Float = 0f,
    val spatialEnabled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Manages persistent storage for unlimited custom equalizer presets via SharedPreferences.
 */
class PresetStorage(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("homes_music_eq_presets", Context.MODE_PRIVATE)
    private val PRESETS_KEY = "custom_presets_json"

    fun getAllCustomPresets(): List<CustomPreset> {
        val jsonStr = prefs.getString(PRESETS_KEY, null) ?: return emptyList()
        val list = mutableListOf<CustomPreset>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val id = obj.optString("id", UUID.randomUUID().toString())
                val name = obj.getString("name")
                val gainsArray = obj.getJSONArray("gains")
                val gains = FloatArray(20) { idx ->
                    if (idx < gainsArray.length()) gainsArray.getDouble(idx).toFloat() else 0f
                }
                val deepBass = obj.optDouble("deepBass", 0.0).toFloat()
                val subBass = obj.optDouble("subBass", deepBass.toDouble()).toFloat()
                val punchyBass = obj.optDouble("punchyBass", (deepBass * 0.85).toDouble()).toFloat()
                val crystalTreble = obj.optDouble("crystalTreble", 0.0).toFloat()
                val spatialEnabled = obj.optBoolean("spatialEnabled", false)
                val createdAt = obj.optLong("createdAt", System.currentTimeMillis())

                list.add(CustomPreset(id, name, gains, deepBass, subBass, punchyBass, crystalTreble, spatialEnabled, createdAt))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun saveCustomPreset(
        name: String,
        gains: FloatArray,
        deepBass: Float,
        subBass: Float = deepBass,
        punchyBass: Float = deepBass * 0.85f,
        crystalTreble: Float = 0f,
        spatialEnabled: Boolean = false
    ): CustomPreset {
        val existing = getAllCustomPresets().toMutableList()
        val trimmed = name.trim()

        existing.removeAll { it.name.equals(trimmed, ignoreCase = true) }

        val newPreset = CustomPreset(
            name = trimmed,
            gains = gains.copyOf(),
            deepBass = deepBass,
            subBass = subBass,
            punchyBass = punchyBass,
            crystalTreble = crystalTreble,
            spatialEnabled = spatialEnabled
        )
        existing.add(0, newPreset)

        persist(existing)
        return newPreset
    }

    fun renameCustomPreset(id: String, newName: String) {
        val existing = getAllCustomPresets().toMutableList()
        val index = existing.indexOfFirst { it.id == id }
        if (index != -1) {
            val old = existing[index]
            existing[index] = old.copy(name = newName.trim())
            persist(existing)
        }
    }

    fun deleteCustomPreset(id: String) {
        val existing = getAllCustomPresets().toMutableList()
        existing.removeAll { it.id == id }
        persist(existing)
    }

    private fun persist(list: List<CustomPreset>) {
        val jsonArray = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            val gainsArray = JSONArray()
            for (g in item.gains) {
                gainsArray.put(g.toDouble())
            }
            obj.put("gains", gainsArray)
            obj.put("deepBass", item.deepBass.toDouble())
            obj.put("subBass", item.subBass.toDouble())
            obj.put("punchyBass", item.punchyBass.toDouble())
            obj.put("crystalTreble", item.crystalTreble.toDouble())
            obj.put("spatialEnabled", item.spatialEnabled)
            obj.put("createdAt", item.createdAt)
            jsonArray.put(obj)
        }
        prefs.edit().putString(PRESETS_KEY, jsonArray.toString()).apply()
    }
}
