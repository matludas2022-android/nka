# Home's Music - Custom Logo & App Icon Setup Guide

## 1. App Launcher Icon (होम स्क्रीन और ऐप ड्रॉअर आइकन):
Android में लॉन्चर आइकन 2 तरीकों से बदला जा सकता है:

### Method A: Android Studio Image Asset Wizard (सबसे आसान और बेस्ट)
1. Android Studio में प्रोजेक्ट खोलें।
2. Project window में `app/src/main/res` फोल्डर पर राइट-क्लिक करें।
3. **New > Image Asset** चुनें।
4. **Icon Type:** `Launcher Icons (Adaptive and Legacy)`
5. **Foreground Layer:** Source Asset में `Image` चुनें और अपनी PNG या SVG फाइल सेलेक्ट करें।
6. **Background Layer:** अपनी पसंद का बैकग्राउंड कलर या इमेज चुनें।
7. **Finish** दबाएं। Android Studio अपने आप सभी resolutions (hdpi, xhdpi, xxhdpi, xxxhdpi) जनरेट कर देगा।

### Method B: Manual File Placement (हाथ से फाइलें रखना)
अगर आप सीधे PNG फाइल्स डालना चाहते हैं, तो अपनी इमेज को नीचे दिए गए फोल्डर्स में रखें (फाइल का नाम `ic_launcher.png` होना चाहिए):
- `app/src/main/res/mipmap-mdpi/ic_launcher.png` (48x48 px)
- `app/src/main/res/mipmap-hdpi/ic_launcher.png` (72x72 px)
- `app/src/main/res/mipmap-xhdpi/ic_launcher.png` (96x96 px)
- `app/src/main/res/mipmap-xxhdpi/ic_launcher.png` (144x144 px)
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` (192x192 px)

गोल आइकन के लिए:
- `ic_launcher_round.png` (उपरोक्त सभी फोल्डर्स में समान साइज़ के साथ)

---

## 2. In-App Header & Notification Logo (ऐप के अंदर और नोटिफिकेशन में दिखने वाला लोगो):
ऐप के अंदर हेडर और लॉक स्क्रीन नोटिफिकेशन में दिखने वाले लोगो के लिए:
- **Folder Path:** `app/src/main/res/drawable/`
- **File Name:** `app_logo.png` (या `app_logo.xml` अगर SVG/Vector है)
- **Code reference:** Jetpack Compose में `painterResource(id = R.drawable.app_logo)` से कॉल किया जाता है।

---

## 3. Web App / Web Preview Logo (वेबसाइट प्रीव्यू में लोगो):
- **Folder Path:** `public/`
- **File Names:**
  - `public/logo.png` (512x512 PNG)
  - `public/logo.svg` (Scalable Vector Icon)
